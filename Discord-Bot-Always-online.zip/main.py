import discord
from discord.ext import commands
import os
from server import stay_alive


intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='/', intents=intents)



stay_alive()
bot.run(os.environ['DISCORD_TOKEN'])